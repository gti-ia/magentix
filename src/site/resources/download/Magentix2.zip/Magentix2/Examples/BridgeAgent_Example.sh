#!/bin/bash



LIBS=$LIBS:Magentix2_Example.jar
LIBS=$LIBS:../magentix2-1.0-jar-with-dependencies.jar



java -cp "$LIBS" BridgeAgent_Example.Run