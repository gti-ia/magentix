package Thomas_Example;

import org.apache.log4j.xml.DOMConfigurator;

import es.upv.dsic.gti_ia.architecture.QueueAgent;
import es.upv.dsic.gti_ia.cAgents.CAgent;
import es.upv.dsic.gti_ia.cAgents.CProcessor;
import es.upv.dsic.gti_ia.core.ACLMessage;
import es.upv.dsic.gti_ia.core.AgentID;
import es.upv.dsic.gti_ia.organization.OMSProxy;

public class AgentPayee extends CAgent {

    private OMSProxy omsProxy = new OMSProxy(this);

    public AgentPayee(AgentID aid) throws Exception {

	super(aid);

    }

    public void escenario2() {

	    omsProxy.acquireRole("member", "virtual");
	    omsProxy.acquireRole( "payee", "travelagency");
	    omsProxy.registerNorm("norma1",
		    "FORBIDDEN_Member_REQUEST_acquireRole_MESSAGE(CONTENT(ROLE_'Payee'))");
	

    }

	@Override
	protected void execution(CProcessor firstProcessor,
			ACLMessage welcomeMessage) {
		DOMConfigurator.configure("configuration/loggin.xml");
		logger.info("Executing, I'm " + getName());

		this.escenario2();
		
	}

	@Override
	protected void finalize(CProcessor firstProcessor,
			ACLMessage finalizeMessage) {
		// TODO Auto-generated method stub
		
	}

}
