package Thomas_Example;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.StringTokenizer;


import org.apache.log4j.xml.DOMConfigurator;


import org.mindswap.owl.EntityFactory;
import org.mindswap.owls.OWLSFactory;
import org.mindswap.owls.process.Process;
import org.mindswap.owls.process.execution.ProcessExecutionEngine;
import org.mindswap.owls.service.Service;
import org.mindswap.query.ValueMap;


import es.upv.dsic.gti_ia.architecture.FIPARequestResponder;
import es.upv.dsic.gti_ia.architecture.MessageTemplate;
import es.upv.dsic.gti_ia.architecture.QueueAgent;
import es.upv.dsic.gti_ia.architecture.FIPANames.InteractionProtocol;
import es.upv.dsic.gti_ia.cAgents.CAgent;
import es.upv.dsic.gti_ia.cAgents.CProcessor;
import es.upv.dsic.gti_ia.cAgents.CFactory;
import es.upv.dsic.gti_ia.cAgents.protocols.FIPA_REQUEST_Participant;
import es.upv.dsic.gti_ia.core.ACLMessage;
import es.upv.dsic.gti_ia.core.AgentID;
import es.upv.dsic.gti_ia.organization.OMSProxy;
import es.upv.dsic.gti_ia.organization.Oracle;
import es.upv.dsic.gti_ia.organization.ProcessDescription;
import es.upv.dsic.gti_ia.organization.SFProxy;

public class AgentProvider extends CAgent {

	private OMSProxy omsProxy = new OMSProxy(this);

	private SFProxy sfProxy = new SFProxy(this);

	private ArrayList<String> results = new ArrayList<String>();

	private Oracle oracle;

	ProcessDescription processDescription = new ProcessDescription(
			"http://localhost:8080/SearchCheapHotel/owl/owls/SearchCheapHotelProcess.owl",
	"SearchCheapHotel");

	public AgentProvider(AgentID aid) throws Exception {

		super(aid);

	}

	public void escenario1() {
		omsProxy.acquireRole("member", "virtual");
	}



	public void escenario3() {
		results = sfProxy.searchService("SearchCheapHotel");

		if (results.size() == 0) {
			System.out.println("profiles are not similar to SearchCheapHotel");
		} else {
			// cogemos el primero por ejemplo
			String URLProfile = sfProxy.getProfile(results.get(0));

			URL profile;
			try {
				profile = new URL(URLProfile);
				oracle = new Oracle(profile);

			} catch (MalformedURLException e) {
				logger.error("ERROR: Profile URL Malformed!");
				e.printStackTrace();
			}


			omsProxy.acquireRole(oracle.getProviderList().get(0), oracle.getProviderUnitList().get(0));
		}
	}

	public void escenario4() {
		processDescription.setProfileID(results.get(0));
		sfProxy.registerProcess(processDescription);
	}

	public void escenario5(){

		omsProxy.acquireRole("payee", "travelagency");

	}

	class myFIPA_REQUEST extends FIPA_REQUEST_Participant {

		@Override
		protected String doAction(CProcessor myProcessor) {
			String next;
			ACLMessage inmsg = myProcessor.getLastReceivedMessage();
			//ACLMessage msg = myProcessor.getLastReceivedMessage().createReply();


			// create an execution engine
			ProcessExecutionEngine exec = OWLSFactory.createExecutionEngine();

			try {
				Process aProcess = processDescription.getProcess(inmsg);


				// initialize the input values to be empty
				ValueMap values = new ValueMap();

				values = processDescription.getServiceRequestValues(inmsg);


				System.out.println("[Provider]Executing... " + values.getValues().toString());
				values = exec.execute(aProcess, values);

				System.out.println("[Provider]Values obtained... :" + values.toString());

				System.out.println("[Provider]Creating inform message to send...");

				//msg.setPerformative(ACLMessage.INFORM);

				System.out.println("[Provider]Before set message content...");
				//msg.setContent(aProcess.getLocalName() + "=" + values.toString());
				myProcessor.getLastReceivedMessage().setContent(aProcess.getLocalName()+"="+values.toString());
				next = "INFORM"; 

			} catch (Exception e) {

				System.out.println("EXCEPTION");
				System.out.println(e);
				e.printStackTrace();
				//msg.setPerformative(ACLMessage.FAILURE);
				next = "FAILURE";
			}
			return next;
		}

		@Override
		protected void doInform(CProcessor myProcessor, ACLMessage response) {
			ACLMessage lastReceivedMessage = myProcessor.getLastReceivedMessage();
			//System.out.println("Soy OMS");
			//System.out.println("ConID: "+myProcessor.getConversationID());
			//System.out.println("Destino: "+lastReceivedMessage.getSender());
			//System.out.println("Perf: INFORM");
			//System.out.println("Content: "+lastReceivedMessage.getContent());
			response.setContent(lastReceivedMessage.getContent());		
		}

		@Override
		protected String doReceiveRequest(CProcessor myProcessor,
				ACLMessage msg) {
			String next;
			ACLMessage response = msg.createReply();
			if (msg != null) {

				try {


					Process aProcess = processDescription.getProcess(msg);
					System.out.println("AGREE");
					response.setPerformative(ACLMessage.AGREE);
					response.setContent(aProcess.getLocalName() + "=Agree");
					next = "AGREE";


				} catch (Exception e) {

					System.out.println("EXCEPTION");
					System.out.println(e);
					e.printStackTrace();
					throw new RuntimeException(e.getMessage());

				}

			} else {

				System.out.println("NOTUNDERSTOOD");
				response.setPerformative(ACLMessage.NOT_UNDERSTOOD);
				response.setContent("NotUnderstood");
				next = "NOT_UNDERSTOOD";
			}

			System.out.println("[Provider]Sending First message:" + response);

			return (next);			
		}
	}

	
	/**
	 * Manages the messages for the  agent provider services
	 */
	/*public class Responder extends FIPARequestResponder {



		public Responder(QueueAgent agent) {
			super(agent, new MessageTemplate(InteractionProtocol.FIPA_REQUEST));

		}// SFResponder

		/**
		 * Receives the messages and takes the message content. Analyzes the
		 * message content and gets the service process and input parameters to
		 * invoke the service. After the service invocation, the agent provider gets the
		 * answer and sends it to the requester agent.
		 * 
		 * @param
		 * @throws RuntimeException
		 */
	/*	protected ACLMessage prepareResponse(ACLMessage msg) {

			ACLMessage response = msg.createReply();
			if (msg != null) {

				try {


					Process aProcess = processDescription.getProcess(msg);
					System.out.println("AGREE");
					response.setPerformative(ACLMessage.AGREE);
					response.setContent(aProcess.getLocalName() + "=Agree");


				} catch (Exception e) {

					System.out.println("EXCEPTION");
					System.out.println(e);
					e.printStackTrace();
					throw new RuntimeException(e.getMessage());

				}

			} else {

				System.out.println("NOTUNDERSTOOD");
				response.setPerformative(ACLMessage.NOT_UNDERSTOOD);
				response.setContent("NotUnderstood");
			}

			System.out.println("[Provider]Sending First message:" + response);

			return (response);

		} // end prepareResponse

		/**
		 * This callback happens if the SF sent a positive reply to the original
		 * request (i.e. an AGREE) if the SF has agreed to supply the service,
		 * the agent provider has to inform the other agent that what they have asked is now
		 * complete (or if it failed)
		 * 
		 * @param inmsg
		 * @param outmsg
		 * @throws RuntimeException
		 */
		/*protected ACLMessage prepareResultNotification(ACLMessage inmsg, ACLMessage outmsg) {




			ACLMessage msg = inmsg.createReply();


			// create an execution engine
			ProcessExecutionEngine exec = OWLSFactory.createExecutionEngine();

			try {
				Process aProcess = processDescription.getProcess(inmsg);


				// initialize the input values to be empty
				ValueMap values = new ValueMap();

				values = processDescription.getServiceRequestValues(inmsg);


				System.out.println("[Provider]Executing... " + values.getValues().toString());
				values = exec.execute(aProcess, values);

				System.out.println("[Provider]Values obtained... :" + values.toString());

				System.out.println("[Provider]Creating inform message to send...");

				msg.setPerformative(ACLMessage.INFORM);

				System.out.println("[Provider]Before set message content...");
				msg.setContent(aProcess.getLocalName() + "=" + values.toString());

			} catch (Exception e) {

				System.out.println("EXCEPTION");
				System.out.println(e);
				e.printStackTrace();
				msg.setPerformative(ACLMessage.FAILURE);
			}
			return (msg);
		} // end prepareResultNotification

	}// end class SFResponder*/

	@Override
	protected void execution(CProcessor firstProcessor,
			ACLMessage welcomeMessage) {
		DOMConfigurator.configure("configuration/loggin.xml");
		logger.info("Executing, I'm " + getName());
		

		CFactory talk = new myFIPA_REQUEST().newFactory("TALK", null,
				0, firstProcessor.getMyAgent());

		// Finally the factory is setup to answer to incoming messages that
		// can start the participation of the agent in a new conversation
		this.addFactoryAsParticipant(talk);	
		
		this.escenario1();
		this.escenario3();
		this.escenario4();
		this.escenario5();		
	}

	@Override
	protected void finalize(CProcessor firstProcessor,
			ACLMessage finalizeMessage) {

	}

}
