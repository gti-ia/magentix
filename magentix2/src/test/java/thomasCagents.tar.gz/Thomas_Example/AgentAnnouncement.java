package Thomas_Example;

import es.upv.dsic.gti_ia.architecture.QueueAgent;
import es.upv.dsic.gti_ia.cAgents.CAgent;
import es.upv.dsic.gti_ia.cAgents.CProcessor;
import es.upv.dsic.gti_ia.core.ACLMessage;
import es.upv.dsic.gti_ia.core.AgentID;
import es.upv.dsic.gti_ia.organization.OMSProxy;
import es.upv.dsic.gti_ia.organization.ProfileDescription;
import es.upv.dsic.gti_ia.organization.SFProxy;

public class AgentAnnouncement extends CAgent {

    public AgentAnnouncement(AgentID aid) throws Exception {

	super(aid);

    }

    // We create the class that will make us the agent proxy oms,facilitates
    // access to the methods of the OMS
    OMSProxy OMSservices = new OMSProxy(this);

    // We create the class that will make us the agent proxy sf,facilitates
    // access to the methods of the SF
    SFProxy SFservices = new SFProxy(this);

    ProfileDescription profile = new ProfileDescription(
	    "http://localhost:8080/SearchCheapHotel/owl/owls/SearchCheapHotelProfile.owl",
	    "SearchCheapHotel");

	@Override
	protected void execution(CProcessor firstProcessor,
			ACLMessage welcomeMessage) {
		logger.info("Executing, I'm " + getName());
		String result;
	
	    result = OMSservices.acquireRole("member", "virtual");
	    logger.info("[AgentAnnoucement]Acquire Role result: " + result + "\n");
	    SFservices.registerProfile(profile);
	    logger.info("[AgentAnnoucement]The operation register Profile return: "
		    + profile.getServiceID() + "\n");		
	}

	@Override
	protected void finalize(CProcessor firstProcessor,
			ACLMessage finalizeMessage) {
		// TODO Auto-generated method stub
		
	}
}
