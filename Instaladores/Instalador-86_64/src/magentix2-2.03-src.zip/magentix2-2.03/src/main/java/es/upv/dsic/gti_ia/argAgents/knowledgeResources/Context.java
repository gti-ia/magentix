package es.upv.dsic.gti_ia.argAgents.knowledgeResources;


/**
 * Implementation of the concept <i>Context</i>
 * 
 */
public class Context {

	public Context() {
    }
}
