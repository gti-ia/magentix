package es.upv.dsic.gti_ia.argAgents.knowledgeResources;

/**
 * Implementation of the concept <i>CaseComponent</i>
 * 
 */
public class CaseComponent {

    public CaseComponent() {
    }
}
